export default {
  getContacts: {
    data: {},
    error: null,
    loading: false
  },
  contactCreate: {
    data: {},
    error: null,
    loading: false
  },
  contactDelete: {
    data: {},
    error: null,
    loading: false
  }
}