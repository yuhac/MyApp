export default {
  loginState: false,
  userInfo: {},
  loading: false
}