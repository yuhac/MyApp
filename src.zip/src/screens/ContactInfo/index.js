import React from 'react'
import {
  View,
  Text,
} from 'react-native'

const ContactInfo = () => {
  return (
    <View>
      <Text>ContactInfo</Text>
    </View>
  );
}

export default ContactInfo
