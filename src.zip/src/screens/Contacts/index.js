import React from 'react'
import {
  View,
  Text,
} from 'react-native'
import Container from '../../components/common/Container';

const Contacts = () => {
  return (
    <Container >
      <Text>Contacts</Text>
    </Container>
  );
}

export default Contacts
