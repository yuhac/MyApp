import React, { useState } from 'react'
import RegisterComponent from '../../components/Register';


const Register = () => {
  const [form, setForm] = useState({})
  const [error, setError] = useState({})

  const onChange = ({ name, value }) => {
    setForm({ ...form, [name]: value })
    if (value) {
      setError(prev => ({ ...prev, [name]: null }))
    }
  }
  const onSubmit = () => {
    if (!form.userName) {
      setError(prev => ({ ...prev, userName: "请输入用户名" }))
    }
    if (!form.email) {
      setError(prev => ({ ...prev, email: "请输入邮箱" }))
    }
    if (!form.password) {
      setError(prev => ({ ...prev, password: "请输入密码" }))
    }

    console.log(form, '---form')
  }

  return (
    <RegisterComponent
      form={form}
      error={error}
      onChange={onChange}
      onSubmit={onSubmit}
    />
  );
}

export default Register
