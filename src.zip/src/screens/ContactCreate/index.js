import React from 'react'
import {
  View,
  Text,
} from 'react-native'

const ContactCreate = () => {
  return (
    <View>
      <Text>ContactCreate</Text>
    </View>
  );
}

export default ContactCreate
