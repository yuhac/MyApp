import React from 'react'
import {
  View,
  Text,
} from 'react-native'

const Settings = () => {
  return (
    <View>
      <Text>Settings</Text>
    </View>
  );
}

export default Settings
