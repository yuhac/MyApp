import React, { useState } from 'react'
import LoginComponent from '../../components/Login';

const Login = () => {
  return (
    <LoginComponent />
  );
}

export default Login
