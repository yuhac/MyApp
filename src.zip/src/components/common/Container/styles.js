import { StyleSheet } from 'react-native'
import colors from '../../../assets/theme/colors'

export default StyleSheet.create({
  wrapper: {
    padding: 20,
    // borderWidth: 1,
    // borderColor: colors.grey,
  }
})